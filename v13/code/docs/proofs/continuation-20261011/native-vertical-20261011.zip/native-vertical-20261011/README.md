# Actual native Linux vertical evidence

Existing pinned :probe plus forced simple/detail/both Runtime turns with actual B1/B2 offers, JEF/C5 packets, outputs and telemetry. Models and pinned binaries downloaded and SHA verified; no software substitute.

`report.json` preserves the initial observer-off script mistake and its outputs. `report-background.json` and the `*-background-turn.json` files preserve the corrected background-enabled runs. `summary.json` scopes execution separately from quality. Native numerical answer errors remain visible and do not pass a semantic quality gate. Full runner, STEP1/2 completion, Redmi and complementarity claims remain false.

`brain-background.sqlite3` contains the synthetic run Store; `data-blobs.zip` contains its exact source blobs. `brain.sqlite3` is the earlier checkpoint. Frozen source subset excludes model weights and caches. See `artifact-manifest.json` for file hashes.
