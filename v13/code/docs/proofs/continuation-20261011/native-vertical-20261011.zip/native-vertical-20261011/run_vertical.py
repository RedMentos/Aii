import sys,json,time,threading,subprocess,traceback,shutil,sqlite3,re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
ROOT=Path('/workspace/scratch/7d5ad9273a5e/native_vertical_oct11');sys.path.insert(0,str(ROOT/'frozen'))
from v13.config import initialize,save_config
from v13.models import ModelManager,catalog,platform_tag,download_file
from v13.bootstrap import install_native
from v13.common import file_hash,atomic_write,dumps
from v13.resources import device
from v13.runtime import Runtime
from v13.proofs import audit_event,assess_native_probe
from v13.verification import GATES,native_capability_profile,b3_doctor
HOME=Path('/workspace/scratch/7d5ad9273a5e/native_baseline_oct11/home');OUT=Path('/workspace/scratch/7d5ad9273a5e/native-vertical-20261011');stop=threading.Event();lock=threading.RLock();r=None;start=time.monotonic()
rep={'proof_kind':'STEP012_NATIVE_VERTICAL_LINUX_INTERMEDIATE','status':'DOWNLOADING','created_wall_time':time.time(),'device':device(),'phone_measured':False,'full_runner_proof':False,'canonical_architecture_complete':False,'budget_seconds':480,'progress':[],'turns':[],'failures':[],'gates':GATES,'claim_limits':['Linux CPU only, no target-phone sustained thermal/energy/RSS proof.','Three forced routes are diagnostic vertical-path execution, not complementarity or learning quality proof.','No software fallback counts as native success; failures and deadlines retained.','Native body weights frozen; B3 latent receiver authority remains zero.']}
def save():
 with lock:rep['elapsed_s']=time.monotonic()-start;atomic_write(OUT/'report.json',dumps(rep))
def notice(x):
 print(x,flush=True)
 with lock:rep['progress'].append({'elapsed_s':time.monotonic()-start,'message':str(x)});save()
def budget():
 if stop.is_set() or time.monotonic()-start>480:raise TimeoutError('Eight-minute diagnostic cap reached')
def wait_idle():
 while not r.idle():
  budget();time.sleep(.05)
def finish_cap():
 stop.set()
 if r:r.cancel()
timer=threading.Timer(480,finish_cap);timer.start();save()
try:
 cfg=initialize(HOME);mm=ModelManager(HOME);spec=catalog();requests=[]
 for key in ('body','gist','needle'):
  s=spec['models'][key];files=list(s['files'])+(s.get('platforms',{}).get(platform_tag(),[]) if key=='needle' else [])
  for f in files:requests.append((f,HOME/'models'/key/f['local_name']))
 rep['download_pins']={key:spec['models'][key] for key in ('body','gist','needle')};save()
 with ThreadPoolExecutor(max_workers=3) as pool:
  futures=[pool.submit(download_file,f,p,notice,stop) for f,p in requests]
  for future in as_completed(futures):future.result();budget()
 for key in ('body','gist','needle'):mm.install(key,notice,stop)
 rep['model_verify']=mm.verify(deep=True);rep['status']='NATIVE_INSTALL';save();install_native(HOME,notice);budget()
 rep['needle_worker_sha256']=file_hash(HOME/'bin/needle-worker');rep['native_runner_sha256']=file_hash(HOME/'bin/llama-server')
 overrides={'learning_mode':'RECORD_ONLY','teacher_enabled':False,'history_turns':0,'threads':2,'deadline_seconds':180,'observer_seconds':90,'answer_tokens':96}
 cfg=cfg|overrides;save_config(HOME,cfg);rep['diagnostic_overrides']=overrides;rep['effective_config']=cfg;save()
 r=Runtime(HOME,notice);rep['model_revisions']=r.revisions();rep['status']='NATIVE_PROBE_RUNNING';save();r.enqueue('probe');wait_idle()
 probe_path=HOME/'exports/native-probe.json'
 if not probe_path.is_file():raise RuntimeError('Existing :probe produced no native-probe.json')
 rep['native_probe']=json.loads(probe_path.read_text());rep['native_probe_assessment']=assess_native_probe(rep['native_probe'],r.revisions());shutil.copyfile(probe_path,OUT/'native-probe.json');rep['status']='RUNTIME_TURNS';save()
 prompt='Project Aurora has a budget of 120 euros. Option Red costs 80 euros and takes 2 days. Option Blue costs 110 euros and takes 1 day. State the remaining budget for each option and briefly describe the trade-off.'
 for route in ('simple','detail','both'):
  budget();r.require_idle();r.cfg['route_override']=route;r.cfg['observer_mode']='off';save_config(HOME,r.cfg);r.session=r.store.new_session('Linux vertical '+route)
  row={'route_override':route,'input':prompt,'started_wall_time':time.time(),'resources_before':r.resources(),'effective_config':dict(r.cfg),'status':'RUNNING'};rep['turns'].append(row);save();t=time.monotonic();eid=r.submit(prompt);row['event_id']=eid;save();wait_idle()
  row['audit']=audit_event(r.store,eid);row['resources_after']=r.resources();row['elapsed_s']=time.monotonic()-t
  row['messages']=r.store.rows('SELECT * FROM messages WHERE event_id=?',(eid,));row['telemetry']=r.store.rows('SELECT * FROM telemetry WHERE event_id=? ORDER BY id',(eid,));row['actions']=r.store.rows('SELECT * FROM actions WHERE event_id=?',(eid,))
  assistant=[m for m in row['messages'] if m['role']=='assistant'];row['status']=assistant[-1]['status'] if assistant else 'NO_ASSISTANT_MESSAGE';out=row['audit'].get('output') or ''
  row['strict_numeric_coverage']={'red_remaining_40':bool(re.search(r'(?is)red.{0,80}\b40\b|\b40\b.{0,80}red',out)),'blue_remaining_10':bool(re.search(r'(?is)blue.{0,80}\b10\b|\b10\b.{0,80}blue',out))}
  atomic_write(OUT/(route+'-turn.json'),dumps(row));save();notice('ROUTE_COMPLETE '+route+' '+row['status'])
 rep['native_capabilities']=native_capability_profile(r);rep['B3']=b3_doctor(r);rep['integrity_errors']=r.store.integrity(True)
 rep['status']='LINUX_VERTICAL_NATIVE_EXECUTION_PASS' if rep['native_probe_assessment']['smoke_valid'] and len(rep['turns'])==3 and all(t['status']=='FINAL' and t['audit']['checks']['actual_model_output'] for t in rep['turns']) else 'LINUX_VERTICAL_PARTIAL';save()
except BaseException as exc:
 rep['status']='LINUX_VERTICAL_INTERRUPTED';rep['failures'].append({'error':repr(exc),'traceback':traceback.format_exc()});save();traceback.print_exc()
finally:
 timer.cancel()
 if r:
  try:r.close();rep['runtime_closed']=True
  except Exception as exc:rep['failures'].append({'close_error':repr(exc)})
 save();shutil.copyfile(Path(__file__),OUT/'run_vertical.py')
 if (HOME/'data/db/brain.sqlite3').is_file():
  con=sqlite3.connect(HOME/'data/db/brain.sqlite3');backup=sqlite3.connect(OUT/'brain.sqlite3');con.backup(backup);backup.close();con.close()
 for p in (HOME/'logs').glob('*.log'):shutil.copyfile(p,OUT/p.name)
 print('FINAL_STATUS='+rep['status'],flush=True)
