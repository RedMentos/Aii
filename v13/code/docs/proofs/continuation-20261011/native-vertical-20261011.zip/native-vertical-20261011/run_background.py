import sys,json,time,traceback,shutil,re,sqlite3
from pathlib import Path
ROOT=Path('/workspace/scratch/7d5ad9273a5e/native_vertical_oct11');sys.path.insert(0,str(ROOT/'frozen'))
from v13.config import initialize,save_config
from v13.runtime import Runtime
from v13.proofs import audit_event
from v13.common import atomic_write,dumps
OUT=Path('/workspace/scratch/7d5ad9273a5e/native-vertical-20261011');HOME=Path('/workspace/scratch/7d5ad9273a5e/native_baseline_oct11/home')
rep={'proof_kind':'STEP012_NATIVE_BACKGROUND_VERTICAL_LINUX_INTERMEDIATE','status':'RUNNING','created_wall_time':time.time(),'phone_measured':False,'full_runner_proof':False,'canonical_architecture_complete':False,'repeat_reason':'First preserved forced-route diagnostics inadvertently disabled observers; repeat with existing background observers to collect actual native OfferPackets.','initial_artifact':'report.json','turns':[],'failures':[],'claim_limits':['Actual Linux CPU native execution only, no Redmi, complementarity quality or native weight learning claim.','Strict_numeric_coverage is lexical only: initial B1 answer containing Blue10 phrasing was semantically wrong; numeric presence cannot prove correctness.']};r=None;start=time.monotonic()
def save():rep['elapsed_s']=time.monotonic()-start;atomic_write(OUT/'report-background.json',dumps(rep))
def notice(x):print(x,flush=True)
try:
 cfg=initialize(HOME)|{'route_override':'simple','observer_mode':'background'};save_config(HOME,cfg);rep['effective_config']=cfg;save();r=Runtime(HOME,notice)
 prompt='Project Aurora has a budget of 120 euros. Option Red costs 80 euros and takes 2 days. Option Blue costs 110 euros and takes 1 day. State the remaining budget for each option and briefly describe the trade-off.'
 for route in ('simple','detail','both'):
  r.require_idle();r.cfg['route_override']=route;r.cfg['observer_mode']='background';save_config(HOME,r.cfg);r.session=r.store.new_session('Linux vertical observers '+route)
  row={'route_override':route,'observer_mode':'background','input':prompt,'status':'RUNNING','resources_before':r.resources(),'effective_config':dict(r.cfg)};rep['turns'].append(row);save();t=time.monotonic();eid=r.submit(prompt);row['event_id']=eid;save()
  while not r.idle():
   if time.monotonic()-start>300:r.cancel();raise TimeoutError('Background collection cap')
   time.sleep(.05)
  row['audit']=audit_event(r.store,eid);row['resources_after']=r.resources();row['elapsed_s']=time.monotonic()-t;row['messages']=r.store.rows('SELECT * FROM messages WHERE event_id=?',(eid,));row['telemetry']=r.store.rows('SELECT * FROM telemetry WHERE event_id=? ORDER BY id',(eid,));row['actions']=r.store.rows('SELECT * FROM actions WHERE event_id=?',(eid,))
  assistant=[m for m in row['messages'] if m['role']=='assistant'];row['status']=assistant[-1]['status'] if assistant else 'NO_ASSISTANT_MESSAGE'
  atomic_write(OUT/(route+'-background-turn.json'),dumps(row));save();notice('BACKGROUND_ROUTE_COMPLETE '+route+' '+row['status'])
 rep['integrity_errors']=r.store.integrity(True);rep['status']='LINUX_NATIVE_BACKGROUND_EXECUTION_COMPLETE' if len(rep['turns'])==3 and all(t['status']=='FINAL' and t['audit']['checks']['actual_model_output'] for t in rep['turns']) else 'LINUX_NATIVE_BACKGROUND_PARTIAL';save()
except BaseException as exc:rep['status']='LINUX_NATIVE_BACKGROUND_INTERRUPTED';rep['failures'].append({'error':repr(exc),'traceback':traceback.format_exc()});save();traceback.print_exc()
finally:
 if r:r.close();rep['runtime_closed']=True
 save();shutil.copyfile(Path(__file__),OUT/'run_background.py')
 con=sqlite3.connect(HOME/'data/db/brain.sqlite3');b=sqlite3.connect(OUT/'brain-background.sqlite3');con.backup(b);b.close();con.close()
 for p in (HOME/'logs').glob('*.log'):shutil.copyfile(p,OUT/(p.stem+'-background.log'))
 print('FINAL_STATUS='+rep['status'],flush=True)
