# V13 Run16 — currently unresolved only

## HARD_BLOCKER
- Full current checkout is unavailable in this host (GitHub DNS failure); full regression and official real-branch privacy scan remain NOT RUN.
- Pinned seven-file LFM2.5-350M snapshot, two exact fixture source files, and `transformers` are missing on this host. Native LP3 four-seed experiment NOT RUN.
- Actual global heavy-job ownership and native memory fit are unverified; local flock cannot attest other hosts. Redmi sustained measurement requires the actual phone.

## RESEARCH_NEEDED
- After a valid LP3 cohort, equal-budget comparison on **model-generated answers** (not merely latent-key retrieval); new preregistration and distinct holdout needed.
- Independently authenticate nonweight HF snapshot assets before claiming upstream exactness.

## CAN_DECIDE_AUTONOMOUSLY
- Full checkout cross-review; official privacy scan; native prerequisites; serial run when externally confirmed safe; external receipt hash publication; further canonical packages without changing the frozen runner.

## USER_DECISION_REQUIRED
- None for this software package. Actual target-phone testing requires user device action when the test bundle is ready.
