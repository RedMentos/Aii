# V13 LP3 Run16 — serial native cohort launcher (software candidate, 2026-10-24)

## Authority / ownership

Remote heads and open PRs inspected first. Base: `codex/lp3-registered-readiness-20261024` @ `b6d1cbaf43f9099a902cd252ae9af133497f6610` (PR #51), stacked on Claude PR #38 `cb959052433e01c29afc007e02b93aef373deb7f`. No newer Claude integration head was visible at inspection. Read current `AGENTS.md`, `v13/AGENTS.md`, `v13/code/docs/HANDOFF_CURRENT.md`, `v13/code/BUILD_STATE.json`, `v13/ROADMAP.md`, `v13/NUTZER_ENTSCHEIDUNGEN.md`, and the complete canonical V13 v10.16.1 headings; canon and all runtime organs remain untouched.

Independent packages with file ownership: (A) `scripts/lp3_serial_cohort.py` owned by launcher implementer, (B) `tests/test_lp3_serial_cohort.py` owned by independent adversarial test reviewer, (C) new `docs/coordination/*RUN16*` and `docs/proofs/.../lp3-run16/*` owned by checkpoint coordinator. Executed sequentially in this session; **no subagent execution claimed**. No heavy native jobs started, no other owner's files edited.

## Mechanism

Opt-in wrapper around the *unchanged* preregistered `lp3_memory_key_candidate.py` four-seed process. Default is read-only readiness. `--run` requires explicit external operator attestations `--owner-verified` and `--ram-fit-verified`, a shared local `flock` path, a fresh native attempt path and a distinct fresh external evidence directory. It obtains a nonblocking advisory local lock, checks pinned assets and source identities under lock, and refuses any known local LP3 process. Launches one process with an argv array (no shell), redirects stdout/stderr into exclusive external log, waits with timeout and signals **only its own child process group** on timeout. Failed attempts preserve native files and logs; no auto-resume/overwrite. A successful exit requires an independent closed-evidence audit with exact fixture sources; only then a receipt is written outside the immutable attempt and SHA-256 is reported. The receipt is NOT independently anchored until its digest is published separately on GitHub. A structurally successful audit does NOT prove the native model ran or passed the original STEP2/B3 gates.

No automatic global ownership detection: local `flock` is advisory and does not coordinate across hosts. Operator attestations are prerequisites, not evidence. No hardcoded assumption that 4GiB suffices. No new dependencies; Python stdlib only, existing local readiness/audit modules reused. This wrapper does not alter the preregistration, predictor, memory keys, scoring, or frozen runtime.

## Evidence and limitations

- 102/102 LP3-focused software/synthetic tests PASS (89 inherited + 13 new); compileall PASS.
- Synthetic child success/failure/timeout, source mismatch, lock contention, symlinked/nested paths, no-ownership and no-memory-fit cases tested. No HF model run and no Redmi proof.
- Current host direct readiness: 4,294,967,296-byte cgroup limit, `transformers` absent, seven HF master files absent, exact LP2/LoRA fixture sources absent from the partial bundle, no local LP3 process seen. BLOCKED. Global owner state and native RAM fit not established.
- Full repository checkout/full suite/official full-branch privacy scan NOT RUN: container DNS cannot resolve github.com; isolated ZIP-based source is not a complete checkout. A scoped manual source review found no new personal data, tokens, network uploads or tool authority.
- Original gates: STEP2 `UTILITY_FAIL`, B3 L1 `FAIL`, Body-JEPA `UNAVAILABLE`, `jepa_weight=0`, `canonical_architecture_complete=false`, `user_full_scope_complete=false`. No promotions.

## Primary technical sources (accessed 2026-10-24)

- Python fcntl advisory flock: https://docs.python.org/3/library/fcntl.html — nonblocking local lock, not global owner proof.
- Linux flock(2) semantics: https://manpages.debian.org/testing/manpages-dev/flock.2.en.html — locks are advisory, remote filesystem semantics vary.
- Python subprocess: https://docs.python.org/3/library/subprocess.html — process group creation, explicit wait/timeout/cleanup.
- Linux kernel cgroup v2: https://www.kernel.org/doc/html/latest/admin-guide/cgroup-v2.html — memory.max is a hard limit, not available memory or successful model-fit proof.
- All incorporated code in this package is original Python standard-library orchestration; no third-party code copied. Existing V13 modules remain separately licensed/owned as before.

## Exact next step

On a complete, current checkout, independently run the full suite and `scripts/public_repo_privacy_scan.py --base <reviewed> --head <new>`, verify remote source bytes, model snapshot/fixtures and current global job ownership and actual RAM headroom. Only then run the **unchanged** four-seed native LP3 cohort serially with explicit attestations; preserve failure rows, audit exact source fixtures, publish receipt SHA-256 outside the attempt, and separately design an equal-budget actual-generated-answer ablation. Do not retry the rejected anyone-writable Drive backup.
