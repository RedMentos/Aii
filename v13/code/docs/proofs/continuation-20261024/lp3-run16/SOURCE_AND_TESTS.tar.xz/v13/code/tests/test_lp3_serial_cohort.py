"""Synthetic-only launch/locking/closure tests; never execute HF model."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts' / 'lp3_serial_cohort.py'
sys.path.insert(0, str(SCRIPT.parent))
spec = importlib.util.spec_from_file_location('lp3_serial_run16', SCRIPT)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


class SerialCohortTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.master = self.root / 'master'
        self.master.mkdir()
        self.candidate = self.root / 'candidate.py'
        self.candidate.write_text('print("synthetic child")\n')
        self.out = self.root / 'native-attempt'
        self.evidence = self.root / 'external-evidence'
        self.lock = self.root / 'shared.lock'
        self.ready = {'status': 'LOCAL_ASSETS_READY_OWNER_UNVERIFIED',
                      'registered_source_blobs_match': True,
                      'local_lp3_process_count': 0,
                      'pinned_master_sha256': 'a'*64}
        self.good_audit = {'audit': 'STRUCTURAL_PASS',
                           'local_source_fixture_consistent': True,
                           'reported_verdict': 'LP3_MEMORY_KEY_NOT_SUPPORTED',
                           'evidence_grade': 'SOURCE_FIXTURES_VERIFIED_UNANCHORED'}

    def call(self, **kwargs):
        options = dict(master=self.master, candidate=self.candidate, out=self.out,
                       evidence_dir=self.evidence, lock_path=self.lock,
                       owner_verified=True, ram_fit_verified=True, timeout=2)
        options.update(kwargs)
        return mod.run_once(**options)

    def test_default_cli_read_only_blocks_missing_assets(self):
        proc = subprocess.run([sys.executable, str(SCRIPT), '--master', str(self.master),
                               '--candidate', str(self.candidate)], capture_output=True, text=True)
        self.assertEqual(proc.returncode, 2)
        self.assertEqual(json.loads(proc.stdout)['status'], 'BLOCKED')
        self.assertFalse(self.lock.exists())
        self.assertFalse(self.evidence.exists())

    def test_no_operator_attestation_no_side_effects(self):
        with self.assertRaises(mod.LaunchBlocked):
            self.call(owner_verified=False)
        with self.assertRaises(mod.LaunchBlocked):
            self.call(ram_fit_verified=False)
        self.assertFalse(self.lock.exists())

    def test_no_native_if_readiness_blocked(self):
        with patch.object(mod, 'check', return_value={**self.ready, 'status': 'BLOCKED'}):
            with self.assertRaises(mod.LaunchBlocked):
                self.call()
        self.assertFalse(self.evidence.exists())
        self.assertFalse(self.out.exists())

    def test_no_native_if_source_registration_mismatch(self):
        with patch.object(mod, 'check', return_value={**self.ready, 'registered_source_blobs_match': False}):
            with self.assertRaises(mod.LaunchBlocked):
                self.call()
        self.assertFalse(self.evidence.exists())

    def test_no_native_if_other_local_process(self):
        with patch.object(mod, 'check', return_value={**self.ready, 'local_lp3_process_count': 1}):
            with self.assertRaises(mod.LaunchBlocked):
                self.call()
        self.assertFalse(self.evidence.exists())

    def test_advisory_lock_rejects_competing_local_owner(self):
        import fcntl
        fd = mod._lock_local(self.lock)
        try:
            with patch.object(mod, 'check', return_value=self.ready):
                with self.assertRaises(mod.LaunchBlocked):
                    self.call()
            self.assertFalse(self.evidence.exists())
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    def test_synthetic_success_is_unpublished_local_receipt_only(self):
        with patch.object(mod, 'check', return_value=self.ready), \
             patch.object(mod, 'audit', return_value=self.good_audit), \
             patch.object(mod, 'receipt_for', return_value={'schema': 'synthetic'}):
            result = self.call()
        self.assertEqual(result['status'], 'LOCAL_CLOSED_EVIDENCE_UNPUBLISHED_ANCHOR')
        self.assertFalse(result['external_anchor_published'])
        self.assertFalse(result['phone_measured'])
        self.assertFalse(result['native_executed'])
        self.assertFalse(result['native_execution_verified'])
        self.assertEqual(result['step2'], 'UTILITY_FAIL')
        self.assertEqual(result['b3_l1'], 'FAIL')
        self.assertEqual(json.loads((self.evidence / 'receipt.json').read_text()), {'schema': 'synthetic'})
        self.assertEqual(json.loads((self.evidence / 'launch_status.json').read_text())['native_returncode'], 0)
        self.assertIn('synthetic child', (self.evidence / 'native.stdout-stderr.log').read_text())
        with self.assertRaises(mod.LaunchBlocked):
            self.call()  # no second attempt or overwrite

    def test_nonzero_native_child_preserved_no_receipt(self):
        self.candidate.write_text('import sys\nsys.exit(7)\n')
        with patch.object(mod, 'check', return_value=self.ready):
            result = self.call()
        self.assertEqual(result['status'], 'NATIVE_ATTEMPT_FAILED_PRESERVED')
        self.assertEqual(result['native_returncode'], 7)
        self.assertFalse((self.evidence / 'receipt.json').exists())
        self.assertTrue((self.evidence / 'launch_status.json').exists())

    def test_timeout_kills_only_owned_process_group(self):
        self.candidate.write_text('import time\ntime.sleep(30)\n')
        with patch.object(mod, 'check', return_value=self.ready):
            result = self.call(timeout=0.1)
        self.assertTrue(result['timed_out'])
        self.assertEqual(result['status'], 'NATIVE_ATTEMPT_FAILED_PRESERVED')
        self.assertFalse((self.evidence / 'receipt.json').exists())

    def test_failed_audit_preserves_log_and_failure_status(self):
        with patch.object(mod, 'check', return_value=self.ready), \
             patch.object(mod, 'audit', side_effect=mod.EvidenceError('synthetic audit fail')):
            with self.assertRaises(mod.EvidenceError):
                self.call()
        record = json.loads((self.evidence / 'launch_status.json').read_text())
        self.assertEqual(record['status'], 'WRAPPER_OR_AUDIT_FAILED_PRESERVED')
        self.assertFalse((self.evidence / 'receipt.json').exists())

    def test_symlink_and_nested_output_rejected(self):
        link = self.root / 'link'
        link.symlink_to(self.out)
        with self.assertRaises(mod.LaunchBlocked):
            self.call(out=link)
        with self.assertRaises(mod.LaunchBlocked):
            self.call(evidence_dir=self.out / 'nested')
        self.assertFalse(self.evidence.exists())

    def test_existing_attempt_never_reused(self):
        self.out.mkdir()
        (self.out / 'seed-31.json').write_text('original')
        with self.assertRaises(mod.LaunchBlocked):
            self.call()
        self.assertEqual((self.out / 'seed-31.json').read_text(), 'original')
        self.assertFalse(self.evidence.exists())

    def test_lock_symlink_refused(self):
        self.lock.symlink_to(self.root / 'arbitrary')
        with self.assertRaises(mod.LaunchBlocked):
            self.call()
        self.assertFalse(self.evidence.exists())


if __name__ == '__main__':
    unittest.main()
