#!/usr/bin/env python3
"""Fail-closed, opt-in serial launcher for the *unchanged* LP3 native cohort.

This wrapper does not modify LP3 preregistration, model, runner or evidence.
It never infers ownership of other hosts. Local flock is advisory, host-scoped.
Native execution requires separate operator verification of global job ownership
and actual memory fit. The default CLI mode only checks local prerequisites.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
from datetime import datetime, timezone

from lp3_native_readiness import inspect as inspect_readiness
from lp3_closed_evidence_audit import audit, receipt_for, EvidenceError


class LaunchBlocked(RuntimeError):
    pass


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def _distinct_paths(out, evidence_dir, lock_path, master):
    """Reject nested outputs, symlinked targets and existing attempt data."""
    out, evidence_dir, lock_path, master = map(Path, (out, evidence_dir, lock_path, master))
    for path in (out, evidence_dir, lock_path):
        if path.is_symlink():
            raise LaunchBlocked('symlinked output/lock path')
    paths = [p.resolve(strict=False) for p in (out, evidence_dir, lock_path, master)]
    if len(set(paths)) != 4:
        raise LaunchBlocked('paths overlap')
    for i, p in enumerate(paths):
        for j, q in enumerate(paths):
            if i != j and (p in q.parents):
                raise LaunchBlocked('nested output, lock, or master paths')
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise LaunchBlocked('attempt exists or is not empty; never overwrite/resume')
    if evidence_dir.exists():
        raise LaunchBlocked('external evidence directory exists; never overwrite')
    if not lock_path.parent.is_dir():
        raise LaunchBlocked('lock parent missing')


def _lock_local(lock_path):
    flags = os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0)
    fd = os.open(lock_path, flags, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise LaunchBlocked('lock is not regular file')
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise LaunchBlocked('another local owner holds LP3 lock') from exc
        return fd
    except BaseException:
        os.close(fd)
        raise


def _write_exclusive(path, obj):
    data = (json.dumps(obj, sort_keys=True, indent=2, allow_nan=False) + '\n').encode('utf-8')
    with Path(path).open('xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    return sha256_bytes(data)


def _fsync_dir(path):
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _wait_owned_child(proc, timeout, grace=5):
    """Only signal the process group created for our own child."""
    try:
        return proc.wait(timeout=timeout), False
    except subprocess.TimeoutExpired:
        if proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        try:
            return proc.wait(timeout=grace), True
        except subprocess.TimeoutExpired:
            if proc.poll() is None:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            return proc.wait(), True


def check(master, candidate, fixture_root=None):
    return inspect_readiness(master, candidate, fixture_root=fixture_root)


def run_once(*, master, candidate, out, evidence_dir, lock_path,
             owner_verified=False, ram_fit_verified=False, timeout=7200):
    """Launch exactly one four-seed native process; preserve failures verbatim.

    ``owner_verified`` and ``ram_fit_verified`` are operator attestations, not
    conclusions from local inspection. Neither is inferred or stored as proof.
    """
    master, candidate, out, evidence_dir, lock_path = map(
        Path, (master, candidate, out, evidence_dir, lock_path))
    if not owner_verified or not ram_fit_verified:
        raise LaunchBlocked('global owner and host RAM-fit attestations required')
    if timeout <= 0:
        raise LaunchBlocked('timeout must be positive')
    _distinct_paths(out, evidence_dir, lock_path, master)
    fd = _lock_local(lock_path)
    try:
        # Lock before scanning, and recheck paths under lock to avoid same-host
        # launch races. This does NOT lock jobs on unrelated hosts.
        _distinct_paths(out, evidence_dir, lock_path, master)
        readiness = check(master, candidate, fixture_root=candidate.parent)
        if (readiness.get('status') != 'LOCAL_ASSETS_READY_OWNER_UNVERIFIED'
                or readiness.get('registered_source_blobs_match') is not True
                or readiness.get('local_lp3_process_count') != 0):
            raise LaunchBlocked('native readiness BLOCKED; no process launched')
        evidence_dir.mkdir(parents=True, exist_ok=False)
        _fsync_dir(evidence_dir.parent)
        record = {'schema': 'V13_LP3_SERIAL_LAUNCH_V1', 'started_utc': utc(),
                  'attempt': str(out), 'source_sha256': sha256_bytes(candidate.read_bytes()),
                  'native_executed': False, 'phone_measured': False,
                  'external_anchor_published': False,
                  'global_owner_verification': 'OPERATOR_ATTESTED_NOT_INDEPENDENTLY_PROVEN',
                  'memory_fit_verification': 'OPERATOR_ATTESTED_NOT_MEASURED_BY_WRAPPER',
                  'step2': 'UTILITY_FAIL', 'b3_l1': 'FAIL',
                  'canonical_architecture_complete': False,
                  'user_full_scope_complete': False}
        cmd = [sys.executable, str(candidate.resolve(strict=True)),
               '--master', str(master.resolve(strict=True)),
               '--master-sha256', readiness['pinned_master_sha256'],
               '--out', str(out.resolve(strict=False))]
        # Runner creates run_manifest/seed rows itself, one immutable file each.
        try:
            with (evidence_dir / 'native.stdout-stderr.log').open('xb') as log:
                proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL,
                                        stdout=log, stderr=subprocess.STDOUT,
                                        start_new_session=True, close_fds=True)
                record['native_process_launched'] = True
                record['native_execution_verified'] = False  # audit cannot prove inference
                rc, timed_out = _wait_owned_child(proc, timeout)
                log.flush(); os.fsync(log.fileno())
            record.update({'native_returncode': rc, 'timed_out': timed_out,
                           'native_log_sha256': sha256_bytes((evidence_dir / 'native.stdout-stderr.log').read_bytes())})
            if rc != 0 or timed_out:
                record['status'] = 'NATIVE_ATTEMPT_FAILED_PRESERVED'
            else:
                fixtures = candidate.parent
                result = audit(out, source=candidate,
                               lp2=fixtures / 'lp2_assignment_objective.py',
                               lora=fixtures / 'lora_bench.py')
                if result.get('audit') != 'STRUCTURAL_PASS' or result.get('local_source_fixture_consistent') is not True:
                    raise EvidenceError('closed source-bound audit did not pass')
                # Receipt lives outside immutable native attempt. Its SHA is
                # only a LOCAL anchor until independently published on GitHub.
                receipt = receipt_for(out)
                digest = _write_exclusive(evidence_dir / 'receipt.json', receipt)
                record.update({'status': 'LOCAL_CLOSED_EVIDENCE_UNPUBLISHED_ANCHOR',
                               'reported_verdict': result['reported_verdict'],
                               'receipt_sha256': digest,
                               'audit_evidence_grade': result['evidence_grade']})
        except BaseException as exc:
            record.update({'status': 'WRAPPER_OR_AUDIT_FAILED_PRESERVED',
                           'error_type': type(exc).__name__})
            raise
        finally:
            record['ended_utc'] = utc()
            _write_exclusive(evidence_dir / 'launch_status.json', record)
            _fsync_dir(evidence_dir)
        return record
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--master', type=Path, required=True)
    ap.add_argument('--candidate', type=Path, default=Path(__file__).with_name('lp3_memory_key_candidate.py'))
    ap.add_argument('--fixture-root', type=Path)
    ap.add_argument('--run', action='store_true', help='opt-in; default is read-only preflight')
    ap.add_argument('--out', type=Path)
    ap.add_argument('--evidence-dir', type=Path)
    ap.add_argument('--lock-path', type=Path)
    ap.add_argument('--owner-verified', action='store_true', help='operator checked all relevant hosts/owners')
    ap.add_argument('--ram-fit-verified', action='store_true', help='operator measured sufficient native RAM headroom')
    ap.add_argument('--timeout', type=int, default=7200)
    a = ap.parse_args()
    try:
        if not a.run:
            result = check(a.master, a.candidate, a.fixture_root)
            print(json.dumps(result, indent=2, sort_keys=True))
            return 0 if result.get('status') == 'LOCAL_ASSETS_READY_OWNER_UNVERIFIED' else 2
        if not all((a.out, a.evidence_dir, a.lock_path)):
            raise LaunchBlocked('--run requires --out, --evidence-dir and --lock-path')
        result = run_once(master=a.master, candidate=a.candidate, out=a.out,
                          evidence_dir=a.evidence_dir, lock_path=a.lock_path,
                          owner_verified=a.owner_verified, ram_fit_verified=a.ram_fit_verified,
                          timeout=a.timeout)
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0 if result['status'] == 'LOCAL_CLOSED_EVIDENCE_UNPUBLISHED_ANCHOR' else 2
    except (LaunchBlocked, OSError, EvidenceError) as exc:
        print(json.dumps({'status': 'BLOCKED_OR_FAILED', 'error_type': type(exc).__name__,
                          'native_success_claim': False}, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
